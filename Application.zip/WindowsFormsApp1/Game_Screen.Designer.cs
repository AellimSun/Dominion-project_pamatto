﻿namespace WindowsFormsApp1
{
    partial class Game_Screen
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game_Screen));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.list_log = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.chatCon = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.CSamount7 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.CSamount6 = new System.Windows.Forms.Label();
            this.CSamount5 = new System.Windows.Forms.Label();
            this.CSamount4 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.CSamount3 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.CSamount2 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.CSamount1 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.amount10 = new System.Windows.Forms.Label();
            this.amount9 = new System.Windows.Forms.Label();
            this.amount8 = new System.Windows.Forms.Label();
            this.amount7 = new System.Windows.Forms.Label();
            this.amount6 = new System.Windows.Forms.Label();
            this.amount5 = new System.Windows.Forms.Label();
            this.amount4 = new System.Windows.Forms.Label();
            this.amount3 = new System.Windows.Forms.Label();
            this.amount2 = new System.Windows.Forms.Label();
            this.amount1 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBox40);
            this.groupBox3.Controls.Add(this.pictureBox39);
            this.groupBox3.Controls.Add(this.pictureBox38);
            this.groupBox3.Controls.Add(this.pictureBox37);
            this.groupBox3.Controls.Add(this.pictureBox36);
            this.groupBox3.Controls.Add(this.pictureBox35);
            this.groupBox3.Controls.Add(this.pictureBox34);
            this.groupBox3.Controls.Add(this.pictureBox33);
            this.groupBox3.Controls.Add(this.pictureBox32);
            this.groupBox3.Controls.Add(this.pictureBox31);
            this.groupBox3.Controls.Add(this.pictureBox18);
            this.groupBox3.Controls.Add(this.pictureBox19);
            this.groupBox3.Controls.Add(this.pictureBox20);
            this.groupBox3.Controls.Add(this.pictureBox21);
            this.groupBox3.Controls.Add(this.pictureBox22);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(269, 521);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(600, 110);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "핸드";
            // 
            // pictureBox40
            // 
            this.pictureBox40.Enabled = false;
            this.pictureBox40.Location = new System.Drawing.Point(352, 25);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(59, 80);
            this.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox40.TabIndex = 15;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Visible = false;
            this.pictureBox40.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox39
            // 
            this.pictureBox39.Enabled = false;
            this.pictureBox39.Location = new System.Drawing.Point(286, 25);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(59, 80);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox39.TabIndex = 14;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Visible = false;
            this.pictureBox39.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox38
            // 
            this.pictureBox38.Enabled = false;
            this.pictureBox38.Location = new System.Drawing.Point(219, 25);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(59, 80);
            this.pictureBox38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox38.TabIndex = 13;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Visible = false;
            this.pictureBox38.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox37
            // 
            this.pictureBox37.Enabled = false;
            this.pictureBox37.Location = new System.Drawing.Point(153, 25);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(59, 80);
            this.pictureBox37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox37.TabIndex = 12;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Visible = false;
            this.pictureBox37.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox36
            // 
            this.pictureBox36.Enabled = false;
            this.pictureBox36.Location = new System.Drawing.Point(86, 25);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(59, 80);
            this.pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox36.TabIndex = 11;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Visible = false;
            this.pictureBox36.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox35
            // 
            this.pictureBox35.Enabled = false;
            this.pictureBox35.Location = new System.Drawing.Point(20, 25);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(59, 80);
            this.pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox35.TabIndex = 10;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Visible = false;
            this.pictureBox35.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox34
            // 
            this.pictureBox34.Enabled = false;
            this.pictureBox34.Location = new System.Drawing.Point(531, 20);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(59, 80);
            this.pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox34.TabIndex = 9;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Visible = false;
            this.pictureBox34.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox33
            // 
            this.pictureBox33.Enabled = false;
            this.pictureBox33.Location = new System.Drawing.Point(465, 20);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(59, 80);
            this.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox33.TabIndex = 8;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Visible = false;
            this.pictureBox33.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox32
            // 
            this.pictureBox32.Enabled = false;
            this.pictureBox32.Location = new System.Drawing.Point(401, 20);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(59, 80);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox32.TabIndex = 7;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Visible = false;
            this.pictureBox32.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox31
            // 
            this.pictureBox31.Enabled = false;
            this.pictureBox31.Location = new System.Drawing.Point(336, 20);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(59, 80);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 6;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Visible = false;
            this.pictureBox31.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox18
            // 
            this.pictureBox18.Location = new System.Drawing.Point(271, 20);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(59, 80);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 1;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(206, 20);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(59, 80);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 2;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(141, 20);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(59, 80);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 3;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(76, 20);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(59, 80);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 4;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.handClick);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(10, 20);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(59, 80);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 5;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Click += new System.EventHandler(this.handClick);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox4.Controls.Add(this.list_log);
            this.groupBox4.Location = new System.Drawing.Point(889, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(229, 389);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // list_log
            // 
            this.list_log.BackColor = System.Drawing.Color.White;
            this.list_log.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.list_log.FormattingEnabled = true;
            this.list_log.ItemHeight = 12;
            this.list_log.Location = new System.Drawing.Point(22, 21);
            this.list_log.Name = "list_log";
            this.list_log.Size = new System.Drawing.Size(187, 336);
            this.list_log.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.chatCon);
            this.groupBox5.Location = new System.Drawing.Point(899, 415);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(199, 216);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "채팅";
            // 
            // chatCon
            // 
            this.chatCon.Location = new System.Drawing.Point(6, 189);
            this.chatCon.Name = "chatCon";
            this.chatCon.Size = new System.Drawing.Size(188, 21);
            this.chatCon.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.listBox1);
            this.groupBox6.Location = new System.Drawing.Point(13, 32);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(199, 132);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "플레이어 목록";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(12, 26);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(177, 88);
            this.listBox1.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Black;
            this.groupBox7.Controls.Add(this.CSamount7);
            this.groupBox7.Controls.Add(this.pictureBox17);
            this.groupBox7.Controls.Add(this.CSamount6);
            this.groupBox7.Controls.Add(this.CSamount5);
            this.groupBox7.Controls.Add(this.CSamount4);
            this.groupBox7.Controls.Add(this.pictureBox15);
            this.groupBox7.Controls.Add(this.pictureBox13);
            this.groupBox7.Controls.Add(this.pictureBox14);
            this.groupBox7.Controls.Add(this.CSamount3);
            this.groupBox7.Controls.Add(this.pictureBox16);
            this.groupBox7.Controls.Add(this.CSamount2);
            this.groupBox7.Controls.Add(this.pictureBox11);
            this.groupBox7.Controls.Add(this.CSamount1);
            this.groupBox7.Controls.Add(this.pictureBox12);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(12, 182);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(199, 279);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "재물/사유지";
            // 
            // CSamount7
            // 
            this.CSamount7.AutoSize = true;
            this.CSamount7.BackColor = System.Drawing.Color.Transparent;
            this.CSamount7.ForeColor = System.Drawing.Color.Red;
            this.CSamount7.Location = new System.Drawing.Point(16, 202);
            this.CSamount7.Name = "CSamount7";
            this.CSamount7.Size = new System.Drawing.Size(17, 12);
            this.CSamount7.TabIndex = 17;
            this.CSamount7.Text = "10";
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(13, 199);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(51, 72);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 7;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.CSClick);
            // 
            // CSamount6
            // 
            this.CSamount6.AutoSize = true;
            this.CSamount6.BackColor = System.Drawing.Color.Transparent;
            this.CSamount6.ForeColor = System.Drawing.Color.Red;
            this.CSamount6.Location = new System.Drawing.Point(139, 122);
            this.CSamount6.Name = "CSamount6";
            this.CSamount6.Size = new System.Drawing.Size(17, 12);
            this.CSamount6.TabIndex = 16;
            this.CSamount6.Text = "10";
            // 
            // CSamount5
            // 
            this.CSamount5.AutoSize = true;
            this.CSamount5.BackColor = System.Drawing.Color.Transparent;
            this.CSamount5.ForeColor = System.Drawing.Color.Red;
            this.CSamount5.Location = new System.Drawing.Point(76, 122);
            this.CSamount5.Name = "CSamount5";
            this.CSamount5.Size = new System.Drawing.Size(17, 12);
            this.CSamount5.TabIndex = 15;
            this.CSamount5.Text = "10";
            // 
            // CSamount4
            // 
            this.CSamount4.AutoSize = true;
            this.CSamount4.BackColor = System.Drawing.Color.Transparent;
            this.CSamount4.ForeColor = System.Drawing.Color.Red;
            this.CSamount4.Location = new System.Drawing.Point(15, 122);
            this.CSamount4.Name = "CSamount4";
            this.CSamount4.Size = new System.Drawing.Size(17, 12);
            this.CSamount4.TabIndex = 14;
            this.CSamount4.Text = "10";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(136, 119);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(51, 72);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 6;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.CSClick);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(73, 119);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(51, 72);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 3;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.CSClick);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(12, 119);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(51, 72);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 4;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.CSClick);
            // 
            // CSamount3
            // 
            this.CSamount3.AutoSize = true;
            this.CSamount3.BackColor = System.Drawing.Color.Transparent;
            this.CSamount3.ForeColor = System.Drawing.Color.Red;
            this.CSamount3.Location = new System.Drawing.Point(139, 36);
            this.CSamount3.Name = "CSamount3";
            this.CSamount3.Size = new System.Drawing.Size(17, 12);
            this.CSamount3.TabIndex = 13;
            this.CSamount3.Text = "10";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(136, 33);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(51, 72);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 5;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.CSClick);
            // 
            // CSamount2
            // 
            this.CSamount2.AutoSize = true;
            this.CSamount2.BackColor = System.Drawing.Color.Transparent;
            this.CSamount2.ForeColor = System.Drawing.Color.Red;
            this.CSamount2.Location = new System.Drawing.Point(76, 36);
            this.CSamount2.Name = "CSamount2";
            this.CSamount2.Size = new System.Drawing.Size(17, 12);
            this.CSamount2.TabIndex = 12;
            this.CSamount2.Text = "10";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(73, 33);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(51, 72);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.CSClick);
            // 
            // CSamount1
            // 
            this.CSamount1.AutoSize = true;
            this.CSamount1.BackColor = System.Drawing.Color.Transparent;
            this.CSamount1.ForeColor = System.Drawing.Color.Red;
            this.CSamount1.Location = new System.Drawing.Point(15, 36);
            this.CSamount1.Name = "CSamount1";
            this.CSamount1.Size = new System.Drawing.Size(17, 12);
            this.CSamount1.TabIndex = 11;
            this.CSamount1.Text = "10";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(12, 33);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(51, 72);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 2;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.CSClick);
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.Black;
            this.groupBox9.Controls.Add(this.label7);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.pictureBox124);
            this.groupBox9.Controls.Add(this.pictureBox123);
            this.groupBox9.Controls.Add(this.label6);
            this.groupBox9.Controls.Add(this.label5);
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(13, 501);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(199, 140);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "덱";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(122, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 19;
            this.label7.Text = "10";
            this.label7.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(21, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "10";
            // 
            // pictureBox124
            // 
            this.pictureBox124.Image = global::WindowsFormsApp1.Properties.Resources.back;
            this.pictureBox124.Location = new System.Drawing.Point(121, 24);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(56, 75);
            this.pictureBox124.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox124.TabIndex = 6;
            this.pictureBox124.TabStop = false;
            // 
            // pictureBox123
            // 
            this.pictureBox123.Image = global::WindowsFormsApp1.Properties.Resources.back;
            this.pictureBox123.Location = new System.Drawing.Point(19, 24);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(56, 75);
            this.pictureBox123.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox123.TabIndex = 7;
            this.pictureBox123.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(111, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "Grave Deck";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(10, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Draw Deck";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 486);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 12);
            this.label9.TabIndex = 11;
            this.label9.Text = "닉네임 / VP";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(320, 468);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(474, 47);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "액션/바이 횟수";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(232, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "Treasure : ";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(338, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "AB 종료";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Buy : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Action : ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.amount10);
            this.groupBox1.Controls.Add(this.amount9);
            this.groupBox1.Controls.Add(this.amount8);
            this.groupBox1.Controls.Add(this.amount7);
            this.groupBox1.Controls.Add(this.amount6);
            this.groupBox1.Controls.Add(this.amount5);
            this.groupBox1.Controls.Add(this.amount4);
            this.groupBox1.Controls.Add(this.amount3);
            this.groupBox1.Controls.Add(this.amount2);
            this.groupBox1.Controls.Add(this.amount1);
            this.groupBox1.Controls.Add(this.pictureBox10);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox9);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(269, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(600, 247);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "시장";
            // 
            // amount10
            // 
            this.amount10.AutoSize = true;
            this.amount10.ForeColor = System.Drawing.Color.Red;
            this.amount10.Location = new System.Drawing.Point(493, 132);
            this.amount10.Name = "amount10";
            this.amount10.Size = new System.Drawing.Size(21, 15);
            this.amount10.TabIndex = 10;
            this.amount10.Text = "10";
            // 
            // amount9
            // 
            this.amount9.AutoSize = true;
            this.amount9.ForeColor = System.Drawing.Color.Red;
            this.amount9.Location = new System.Drawing.Point(371, 132);
            this.amount9.Name = "amount9";
            this.amount9.Size = new System.Drawing.Size(21, 15);
            this.amount9.TabIndex = 9;
            this.amount9.Text = "10";
            // 
            // amount8
            // 
            this.amount8.AutoSize = true;
            this.amount8.ForeColor = System.Drawing.Color.Red;
            this.amount8.Location = new System.Drawing.Point(252, 132);
            this.amount8.Name = "amount8";
            this.amount8.Size = new System.Drawing.Size(21, 15);
            this.amount8.TabIndex = 8;
            this.amount8.Text = "10";
            // 
            // amount7
            // 
            this.amount7.AutoSize = true;
            this.amount7.ForeColor = System.Drawing.Color.Red;
            this.amount7.Location = new System.Drawing.Point(135, 132);
            this.amount7.Name = "amount7";
            this.amount7.Size = new System.Drawing.Size(21, 15);
            this.amount7.TabIndex = 7;
            this.amount7.Text = "10";
            // 
            // amount6
            // 
            this.amount6.AutoSize = true;
            this.amount6.ForeColor = System.Drawing.Color.Red;
            this.amount6.Location = new System.Drawing.Point(23, 132);
            this.amount6.Name = "amount6";
            this.amount6.Size = new System.Drawing.Size(21, 15);
            this.amount6.TabIndex = 6;
            this.amount6.Text = "10";
            // 
            // amount5
            // 
            this.amount5.AutoSize = true;
            this.amount5.ForeColor = System.Drawing.Color.Red;
            this.amount5.Location = new System.Drawing.Point(493, 21);
            this.amount5.Name = "amount5";
            this.amount5.Size = new System.Drawing.Size(21, 15);
            this.amount5.TabIndex = 5;
            this.amount5.Text = "10";
            // 
            // amount4
            // 
            this.amount4.AutoSize = true;
            this.amount4.ForeColor = System.Drawing.Color.Red;
            this.amount4.Location = new System.Drawing.Point(371, 21);
            this.amount4.Name = "amount4";
            this.amount4.Size = new System.Drawing.Size(21, 15);
            this.amount4.TabIndex = 4;
            this.amount4.Text = "10";
            // 
            // amount3
            // 
            this.amount3.AutoSize = true;
            this.amount3.ForeColor = System.Drawing.Color.Red;
            this.amount3.Location = new System.Drawing.Point(252, 21);
            this.amount3.Name = "amount3";
            this.amount3.Size = new System.Drawing.Size(21, 15);
            this.amount3.TabIndex = 3;
            this.amount3.Text = "10";
            // 
            // amount2
            // 
            this.amount2.AutoSize = true;
            this.amount2.ForeColor = System.Drawing.Color.Red;
            this.amount2.Location = new System.Drawing.Point(135, 21);
            this.amount2.Name = "amount2";
            this.amount2.Size = new System.Drawing.Size(21, 15);
            this.amount2.TabIndex = 2;
            this.amount2.Text = "10";
            // 
            // amount1
            // 
            this.amount1.AutoSize = true;
            this.amount1.ForeColor = System.Drawing.Color.Red;
            this.amount1.Location = new System.Drawing.Point(23, 21);
            this.amount1.Name = "amount1";
            this.amount1.Size = new System.Drawing.Size(21, 15);
            this.amount1.TabIndex = 1;
            this.amount1.Text = "10";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(492, 128);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(85, 101);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(492, 17);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(85, 101);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(369, 128);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(85, 101);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(369, 17);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(85, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(250, 128);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(85, 101);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(250, 17);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(85, 101);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(133, 128);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(85, 101);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(133, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(85, 101);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(19, 128);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(85, 101);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.marketClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(19, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(85, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.marketClick);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pictureBox53);
            this.groupBox10.Controls.Add(this.pictureBox54);
            this.groupBox10.Controls.Add(this.pictureBox55);
            this.groupBox10.Controls.Add(this.pictureBox50);
            this.groupBox10.Controls.Add(this.pictureBox51);
            this.groupBox10.Controls.Add(this.pictureBox52);
            this.groupBox10.Controls.Add(this.pictureBox47);
            this.groupBox10.Controls.Add(this.pictureBox48);
            this.groupBox10.Controls.Add(this.pictureBox44);
            this.groupBox10.Controls.Add(this.pictureBox49);
            this.groupBox10.Controls.Add(this.pictureBox45);
            this.groupBox10.Controls.Add(this.pictureBox46);
            this.groupBox10.Controls.Add(this.pictureBox41);
            this.groupBox10.Controls.Add(this.pictureBox42);
            this.groupBox10.Controls.Add(this.pictureBox43);
            this.groupBox10.Controls.Add(this.pictureBox27);
            this.groupBox10.Controls.Add(this.pictureBox30);
            this.groupBox10.Controls.Add(this.pictureBox29);
            this.groupBox10.Controls.Add(this.pictureBox28);
            this.groupBox10.Controls.Add(this.pictureBox26);
            this.groupBox10.Controls.Add(this.pictureBox25);
            this.groupBox10.ForeColor = System.Drawing.Color.White;
            this.groupBox10.Location = new System.Drawing.Point(269, 301);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(600, 145);
            this.groupBox10.TabIndex = 10;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "g";
            // 
            // pictureBox53
            // 
            this.pictureBox53.Enabled = false;
            this.pictureBox53.Location = new System.Drawing.Point(535, 47);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(59, 80);
            this.pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox53.TabIndex = 24;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Visible = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.Enabled = false;
            this.pictureBox54.Location = new System.Drawing.Point(521, 35);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(59, 80);
            this.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox54.TabIndex = 23;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Visible = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.Enabled = false;
            this.pictureBox55.Location = new System.Drawing.Point(511, 20);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(59, 80);
            this.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox55.TabIndex = 22;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Visible = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.Enabled = false;
            this.pictureBox50.Location = new System.Drawing.Point(451, 47);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(59, 80);
            this.pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox50.TabIndex = 21;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Visible = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.Enabled = false;
            this.pictureBox51.Location = new System.Drawing.Point(437, 35);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(59, 80);
            this.pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox51.TabIndex = 20;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Visible = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.Enabled = false;
            this.pictureBox52.Location = new System.Drawing.Point(427, 20);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(59, 80);
            this.pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox52.TabIndex = 19;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Visible = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Enabled = false;
            this.pictureBox47.Location = new System.Drawing.Point(367, 47);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(59, 80);
            this.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox47.TabIndex = 18;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Visible = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Enabled = false;
            this.pictureBox48.Location = new System.Drawing.Point(353, 35);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(59, 80);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox48.TabIndex = 17;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Visible = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Enabled = false;
            this.pictureBox44.Location = new System.Drawing.Point(283, 47);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(59, 80);
            this.pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox44.TabIndex = 18;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Visible = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.Enabled = false;
            this.pictureBox49.Location = new System.Drawing.Point(343, 20);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(59, 80);
            this.pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox49.TabIndex = 16;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Visible = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.Enabled = false;
            this.pictureBox45.Location = new System.Drawing.Point(269, 35);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(59, 80);
            this.pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox45.TabIndex = 17;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Visible = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.Enabled = false;
            this.pictureBox46.Location = new System.Drawing.Point(259, 20);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(59, 80);
            this.pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox46.TabIndex = 16;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Visible = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.Enabled = false;
            this.pictureBox41.Location = new System.Drawing.Point(199, 47);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(59, 80);
            this.pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox41.TabIndex = 15;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Visible = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Enabled = false;
            this.pictureBox42.Location = new System.Drawing.Point(185, 35);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(59, 80);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox42.TabIndex = 14;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Visible = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Enabled = false;
            this.pictureBox43.Location = new System.Drawing.Point(175, 20);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(59, 80);
            this.pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox43.TabIndex = 13;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Visible = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Enabled = false;
            this.pictureBox27.Location = new System.Drawing.Point(33, 47);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(59, 80);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 12;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Visible = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Enabled = false;
            this.pictureBox30.Location = new System.Drawing.Point(115, 47);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(59, 80);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 11;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Visible = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Enabled = false;
            this.pictureBox29.Location = new System.Drawing.Point(101, 35);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(59, 80);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 10;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Visible = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Enabled = false;
            this.pictureBox28.Location = new System.Drawing.Point(91, 20);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(59, 80);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 9;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Visible = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Enabled = false;
            this.pictureBox26.Location = new System.Drawing.Point(21, 35);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(59, 80);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 7;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Visible = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Enabled = false;
            this.pictureBox25.Location = new System.Drawing.Point(7, 20);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(59, 80);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 6;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Visible = false;
            // 
            // Game_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1130, 694);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "Game_Screen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Game_Screen_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label CSamount7;
        private System.Windows.Forms.Label CSamount6;
        private System.Windows.Forms.Label CSamount5;
        private System.Windows.Forms.Label CSamount4;
        private System.Windows.Forms.Label CSamount3;
        private System.Windows.Forms.Label CSamount2;
        private System.Windows.Forms.Label CSamount1;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox124;
        private System.Windows.Forms.PictureBox pictureBox123;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox chatCon;
        private System.Windows.Forms.Label amount10;
        private System.Windows.Forms.Label amount9;
        private System.Windows.Forms.Label amount8;
        private System.Windows.Forms.Label amount7;
        private System.Windows.Forms.Label amount6;
        private System.Windows.Forms.Label amount5;
        private System.Windows.Forms.Label amount4;
        private System.Windows.Forms.Label amount3;
        private System.Windows.Forms.Label amount2;
        private System.Windows.Forms.Label amount1;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox list_log;
    }
}

